const path = require('path');

module.exports = {
  dependencies: {
    'react-native-maps': {
      root: path.join(__dirname, '..'),
    },
  },
};
