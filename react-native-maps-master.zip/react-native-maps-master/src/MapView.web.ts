//@ts-ignore
export {default} from 'react-native-web/dist/modules/UnimplementedView';
