//
//  AIRMapLocalTileManager.h
//  AirMaps
//
//  Created by Peter Zavadsky on 01/12/2017.
//  Copyright © 2017 Christopher. All rights reserved.
//

#import <React/RCTViewManager.h>

@interface AIRMapLocalTileManager : RCTViewManager

@end
