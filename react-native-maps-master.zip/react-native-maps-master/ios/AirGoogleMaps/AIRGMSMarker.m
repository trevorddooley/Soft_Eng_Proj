//
//  AIRGMSMarker.m
//  AirMaps
//
//  Created by Gil Birman on 9/5/16.
//

#ifdef HAVE_GOOGLE_MAPS

#import "AIRGMSMarker.h"

@implementation AIRGMSMarker

@end

#endif
